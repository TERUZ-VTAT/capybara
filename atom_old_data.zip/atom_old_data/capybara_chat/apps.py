from django.apps import AppConfig


class CapybaraChatConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'capybara_chat'
